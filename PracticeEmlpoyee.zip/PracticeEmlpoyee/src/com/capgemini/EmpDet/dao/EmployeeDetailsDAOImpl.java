package com.capgemini.EmpDet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.EmpDet.bean.EmployeeDetailBean;
import com.capgemini.EmpDet.dao.QueryMapperEmployeeDetails;
import com.capgemini.EmpDet.exception.EmployeeDetailsException;
import com.capgemini.EmpDet.util.DBConnection;
import com.capgemini.mobpur.bean.MobileBean;
import com.capgemini.mobpur.dao.QueryMapperMobile;
import com.capgemini.mobpur.exception.MobilePurchaseException;

public class EmployeeDetailsDAOImpl implements IEmployeeDetailsDAO {
	@Override
	public boolean addEmployee(EmployeeDetailBean employeedetail)
			throws EmployeeDetailsException{
		int records = 0;
		boolean isadded = false;
		
		try(Connection connEmployeeDetail  = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
		connEmployeeDetail.prepareStatement(QueryMapperEmployeeDetails.ADD_EMPLOYEE);
	){
		
			preparedStatement.setInt(1, employeedetail.getEmpid());
			preparedStatement.setString(2, employeedetail.getEmpname());
			preparedStatement.setInt(3, employeedetail.getEmpsalary());
			preparedStatement.setString(4, employeedetail.getEmpDept());
			preparedStatement.setString(5, employeedetail.getEmpDesg());
		records = preparedStatement.executeUpdate();
		if(records>0){
			isadded= true;
		}
		
	}catch(SQLException sqlEx){
		throw new EmployeeDetailsException(sqlEx.getMessage());
	}
	return isadded;
	}

	@Override
	public List<EmployeeDetailBean> searchEmployee(int empid)
			throws EmployeeDetailsException {
		
			List<EmployeeDetailBean>employeeList = new ArrayList<EmployeeDetailBean>();
			
			try(Connection connEmployeeDetail  = DBConnection.getInstance().getConnection();	
			
			PreparedStatement preparedStatement=
			connEmployeeDetail.prepareStatement(QueryMapperEmployeeDetails.SEARCH_EMPLOYEE);
					
		){
				preparedStatement.setInt(1, empid);
				ResultSet rsemployeedetails = preparedStatement.executeQuery();
			
			while(rsemployeedetails.next()){
				EmployeeDetailBean employee = new EmployeeDetailBean();
				
				employee.setEmpname(rsemployeedetails.getString("Employee name"));
				employee.setEmpsalary(rsemployeedetails.getInt("name"));
				employee.setEmpDept(rsemployeedetails.getString("Department"));
				employee.setEmpDesg(rsemployeedetails.getString("Designation"));
				
				employeeList.add(employee);
			}
			if(employeeList.size() == 0){
				throw new EmployeeDetailsException("No records found.");
			}
		}catch(SQLException sqlEx){
			throw new EmployeeDetailsException(sqlEx.getMessage());
		}
		return employeeList;
		
	}

	@Override
	public boolean updateEmployee(EmployeeDetailBean employeedetail)
			throws EmployeeDetailsException {
		int records = 0;
		boolean isUpdated = false;
		
		try(Connection connEmployeeDetail  = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
		connEmployeeDetail.prepareStatement(QueryMapperEmployeeDetails.UPDATE_EMPLOYEE);
	){
		
		preparedStatement.setInt(1, empid);
		records = preparedStatement.executeUpdate();
		if(records>0){
			isUpdated = true;
		}
		
	}catch(SQLException sqlEx){
		throw new EmployeeDetailsException (sqlEx.getMessage());
	}
	return isUpdated;
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeDetailsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<EmployeeDetailBean> viewAllEmployees()
			throws EmployeeDetailsException {
		// TODO Auto-generated method stub
		return null;
	}

}
