package com.capgemini.EmpDet.bean;

public class EmployeeDetailBean {
     private int empid;
     private String empname;
     private int empsalary;
     private String empDept;
     private String empDesg;
	public EmployeeDetailBean() {
		super();
	}
	public EmployeeDetailBean(int empid, String empname, int empsalary,
			String empDept, String empDesg) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empsalary = empsalary;
		this.empDept = empDept;
		this.empDesg = empDesg;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(int empsalary) {
		this.empsalary = empsalary;
	}
	public String getEmpDept() {
		return empDept;
	}
	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}
	public String getEmpDesg() {
		return empDesg;
	}
	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}
	@Override
	public String toString() {
		return "EmployeeDetailBean [empid=" + empid + ", empname=" + empname
				+ ", empsalary=" + empsalary + ", empDept=" + empDept
				+ ", empDesg=" + empDesg + "]";
	}
	
     
}
